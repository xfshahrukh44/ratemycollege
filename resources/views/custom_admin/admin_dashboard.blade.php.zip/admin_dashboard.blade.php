@extends('layouts.backend')

@section('css')
<style>


</style>
@endsection





@section('content')



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - Rate My Collages & Coaches</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

    @include('custom_admin.admin_css')
    
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="pagetitle">
      <h1>Reports</h1>
    </div>
    <div>
      <a href="#">Show Activity Log</a>
    </div>
  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
   
   @include('custom_admin.admin_nav')

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <section class="section dashboard">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            
            
                <div class="card-title d-flex">
                  <div class="col-md-4"></div>
                  <div class="col-md-4"></div>
                  
                  <div class="chart-filter col-md-4 d-flex px-4">
                      
                      <label style="margin-top: 5px;"> Select Year </label>
                      <div class="col col mx-2">
                        <select class="form-select" aria-label="Default select example">
                          <option vallue="2024" selected>2024</option>
                          <option value="2023">2023</option>
                          <option value="2022">2022</option>
                          <option value="2021">2021</option>
                          <option value="2020">2020</option>
                          <option value="2019">2019</option>
                          <option value="2018">2018</option>
                          <option value="2017">2017</option>
                          <option value="2016">2016</option>
                          <option value="2015">2015</option>
                        </select>
                      </div>
                      
                  </div>
                </div>
            
            
            <div class="col-xxl-12 col-md-12">
              <div class="card">
                
                
                
                
                
                <div class="card-body">


                  <!-- Column Chart -->
                  
                    <?php
                     
                        $dataPoints2 = array( 
                        	array("y" => 3373.64, "label" => "Germany" ),
                        	array("y" => 2435.94, "label" => "France" ),
                        	array("y" => 1842.55, "label" => "China" ),
                        	array("y" => 1828.55, "label" => "Russia" ),
                        	array("y" => 1039.99, "label" => "Switzerland" ),
                        	array("y" => 765.215, "label" => "Japan" ),
                        	array("y" => 612.453, "label" => "Netherlands" )
                        );
                         
                    ?>
                    
                <!-- End Column Chart -->

                <script>
                
                    window.onload = function() {
                     
                    var chart = new CanvasJS.Chart("chartContainer2", {
                    	animationEnabled: true,
                    	theme: "light2",
                    	title:{
                    		text: "Gold Reserves"
                    	},
                    	axisY: {
                    		title: "Gold Reserves (in tonnes)"
                    	},
                    	data: [{
                    		type: "column",
                    		yValueFormatString: "#,##0.## tonnes",
                    		dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
                    	}]
                    });
                    chart.render();
                     
                    }
                
                </script>
                
                
                <div id="chartContainer2" style="height: 370px; width: 100%;"></div>
                <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>


                </div>
              </div>
            </div>
          </div>
        </div>
        
        
        
        
        
        <div class="col-lg-12">
          <div class="row">
            
            
            
            <div class="col-xxl-6 col-md-6">
                <div class="card">
                    
                  <div class="card-title d-flex">
                    <div class="col-md-8"><h5 class="card-title py-0 px-4">Ratings by year</h5></div>
                    <!--<div class="chart-filter col-md-4 d-flex px-4">-->
                    <!--    <div class="col col mx-2">-->
                    <!--      <select class="form-select" aria-label="Default select example">-->
                    <!--        <option selected>Sports</option>-->
                    <!--        <option value="1">One</option>-->
                    <!--        <option value="2">Two</option>-->
                    <!--        <option value="3">Three</option>-->
                    <!--      </select>-->
                    <!--    </div>-->
                    <!--</div>-->
                  </div>
                  
                   
                   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                    <script type="text/javascript">
                      google.charts.load('current', {'packages':['corechart']});
                      google.charts.setOnLoadCallback(drawChart);
                
                      function drawChart() {
                
                        var data = google.visualization.arrayToDataTable([
                          ['Task', 'Hours per Day'],
                          ['Work',     11],
                          ['Eat',      2],
                          ['Commute',  2],
                          ['Watch TV', 2],
                          ['Sleep',    7]
                        ]);
                
                        var options = {
                          title: 'My Daily Activities'
                        };
                
                        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                
                        chart.draw(data, options);
                      }
                    </script>
                    
                    <div id="piechart" style="width: 900px; height: 500px;"></div>
                    
                   
    
                  </div>
                </div>
            </div>
            
            
            
            
            <div class="col-xxl-6 col-md-6">
            <div class="card">
              <div class="card-title d-flex">
                <div class="col-md-8"><h5 class="card-title py-0 px-4">Scouting Report</h5></div>
                <div class="chart-filter col-md-4 d-flex px-4">
                    
                </div>
              </div>
              <div class="card-body">
                <!-- Bar Chart -->
                  <div id="barChart"></div>

                  <script>
                    document.addEventListener("DOMContentLoaded", () => {
                      new ApexCharts(document.querySelector("#barChart"), {
                        series: [{
                          data: [400, 430, 448, 470, 540]
                        }],
                        chart: {
                          type: 'bar',
                          height: 350
                        },
                        plotOptions: {
                          bar: {
                            borderRadius: 4,
                            horizontal: true,
                          }
                        },
                        dataLabels: {
                          enabled: false
                        },
                        xaxis: {
                          categories: ['⭐⭐⭐⭐⭐', '⭐⭐⭐⭐', '⭐⭐⭐', '⭐⭐', '⭐'
                          ],
                        }
                      }).render();
                    });
                  </script>
                  <!-- End Bar Chart -->

              </div>
            </div>
            </div>
          </div>
        </div>
        
        
        <!--<div class="col-lg-12">-->
        <!--  <div class="row">-->
        <!--    <div class="col-xxl-4 col-md-4">-->
        <!--      <div class="card">-->
        <!--        <div class="card-title d-flex">-->
        <!--          <div class="col-md-12">-->
        <!--            <h5 class="card-title px-4 py-0">Top 5 Highest Rated</h5>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--        <div class="card-body">-->
        <!--            <ul class="list-group list-group-numbered">-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--            </ul>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--    </div>-->
        <!--    <div class="col-xxl-4 col-md-4">-->
        <!--      <div class="card">-->
        <!--        <div class="card-title d-flex">-->
        <!--          <div class="col-md-12">-->
        <!--            <h5 class="card-title px-4 py-0">Top 5 Lowest Rated</h5>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--        <div class="card-body">-->
        <!--            <ul class="list-group list-group-numbered">-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--            </ul>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--    </div>-->
        <!--    <div class="col-xxl-4 col-md-4">-->
        <!--      <div class="card">-->
        <!--        <div class="card-title d-flex">-->
        <!--          <div class="col-md-12">-->
        <!--            <h5 class="card-title px-4 py-0">Most Rated School</h5>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--        <div class="card-body">-->
        <!--            <ul class="list-group list-group-numbered">-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--              <li class="list-group-item">Jesse Zafiratos</li>-->
        <!--            </ul>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--    </div>-->
        <!--  </div>-->
        <!--</div>-->
      </div>
    </section>

  </main><!-- End #main -->

 

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

@include('custom_admin.admin_js')


</body>

</html>



@endsection






@section('js')
<script type="text/javascript">
    
    
</script>
@endsection
